#pragma once



class Model {



};


class Static : Model {



};



class Animated : Model {



};






